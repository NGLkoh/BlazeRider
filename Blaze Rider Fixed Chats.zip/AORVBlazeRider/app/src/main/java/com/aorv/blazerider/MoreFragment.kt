package com.aorv.blazerider

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.imageview.ShapeableImageView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class MoreFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_more, container, false)

        // Initialize Firebase Auth and Firestore
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Get current user
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // Set email from Firebase Auth
            view.findViewById<TextView>(R.id.user_email).text = currentUser.email ?: "user@gmail.com"

            // Fetch user data from Firestore
            db.collection("users").document(currentUser.uid).get()
                .addOnSuccessListener { document ->
                    if (document != null && document.exists()) {
                        val firstName = document.getString("firstName") ?: ""
                        val lastName = document.getString("lastName") ?: ""
                        val profileImageUrl = document.getString("profileImageUrl")

                        // Set user name
                        view.findViewById<TextView>(R.id.user_name).text = "$firstName $lastName"

                        // Load profile image using Glide
                        profileImageUrl?.let { url ->
                            if (url.isNotEmpty()) {
                                Glide.with(this)
                                    .load(url)
                                    .apply(RequestOptions()
                                        .placeholder(R.drawable.ic_blank)
                                        .error(R.drawable.ic_blank))
                                    .into(view.findViewById<ShapeableImageView>(R.id.user_image))
                            } else {
                                // Set default image if profileImageUrl is empty
                                view.findViewById<ShapeableImageView>(R.id.user_image)
                                    .setImageResource(R.drawable.ic_blank)
                            }
                        } ?: run {
                            // Set default image if profileImageUrl is null
                            view.findViewById<ShapeableImageView>(R.id.user_image)
                                .setImageResource(R.drawable.ic_blank)
                        }
                    } else {
                        // Handle case where document doesn't exist
                        view.findViewById<TextView>(R.id.user_name).text = "User"
                        view.findViewById<ShapeableImageView>(R.id.user_image)
                            .setImageResource(R.drawable.ic_blank)
                    }
                }
                .addOnFailureListener {
                    // Handle error
                    view.findViewById<TextView>(R.id.user_name).text = "User"
                    view.findViewById<ShapeableImageView>(R.id.user_image)
                        .setImageResource(R.drawable.ic_blank)
                }
        } else {
            // Handle case where no user is logged in
            view.findViewById<TextView>(R.id.user_name).text = "User"
            view.findViewById<TextView>(R.id.user_email).text = "user@gmail.com"
            view.findViewById<ShapeableImageView>(R.id.user_image)
                .setImageResource(R.drawable.ic_blank)
        }

        // Set click listener for edit profile
        view.findViewById<View>(R.id.edit_profile).setOnClickListener {
            val intent = Intent(requireContext(), EditProfileActivity::class.java)
            startActivity(intent)
        }

        // Set click listener for logout item
        view.findViewById<View>(R.id.logout_item).setOnClickListener {
            showLogoutDialog()
        }

        return view
    }

    private fun showLogoutDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes") { _, _ ->
                // Perform logout
                auth.signOut()

                // Navigate to MainMenuActivity
                val intent = Intent(requireContext(), MainMenuActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            }
            .setNegativeButton("No") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}