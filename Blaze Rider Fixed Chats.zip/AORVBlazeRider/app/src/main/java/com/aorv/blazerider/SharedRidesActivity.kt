package com.aorv.blazerider

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.appbar.MaterialToolbar

class SharedRidesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shared_rides)

        // Set up close button
        val toolbar = findViewById<MaterialToolbar>(R.id.top_app_bar)
        toolbar.setNavigationOnClickListener {
            finish() // Close the activity
        }

        // Set up ViewPager2 and TabLayout
        val viewPager = findViewById<ViewPager2>(R.id.view_pager)
        val tabLayout = findViewById<TabLayout>(R.id.tab_layout)

        viewPager.adapter = SharedRidesPagerAdapter(this)

        // Connect TabLayout with ViewPager2
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "Shared Rides"
                1 -> "My Rides"
                else -> null
            }
        }.attach()
    }

    private inner class SharedRidesPagerAdapter(fa: FragmentActivity) : FragmentStateAdapter(fa) {
        override fun getItemCount(): Int = 2

        override fun createFragment(position: Int): Fragment = when (position) {
            0 -> SharedRidesFragment()
            1 -> MyRidesFragment()
            else -> throw IllegalStateException("Unexpected position $position")
        }
    }
}