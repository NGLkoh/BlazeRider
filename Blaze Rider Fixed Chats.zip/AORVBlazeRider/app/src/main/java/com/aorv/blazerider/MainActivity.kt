package com.aorv.blazerider

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Timer
import kotlin.concurrent.timerTask

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var progressBar: ProgressBar
    private val TAG = "MainActivity"

    companion object {
        // Static flag to track if checkUserStatus has run in this app process
        private var hasCheckedUserStatus = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Firebase Auth and Firestore
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Setup ProgressBar
        progressBar = findViewById<ProgressBar>(R.id.loadingProgressBar).apply {
            visibility = View.VISIBLE
            isIndeterminate = true
            indeterminateDrawable.setColorFilter(
                resources.getColor(android.R.color.holo_red_dark),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        // Check if this is a fresh app launch and checkUserStatus hasn't run yet
        if (savedInstanceState == null && !hasCheckedUserStatus) {
            Log.d(TAG, "Fresh app launch and first status check, scheduling checkUserStatus")
            hasCheckedUserStatus = true // Mark as checked
            // Check user login status after a short delay to show loading
            Timer().schedule(timerTask {
                runOnUiThread {
                    checkUserStatus()
                }
            }, 1000)
        } else {
            Log.d(TAG, "Not a fresh launch or checkUserStatus already ran, redirecting to MainMenuActivity")
            progressBar.visibility = View.GONE
            startActivity(Intent(this, MainMenuActivity::class.java))
            finish()
        }
    }

    private fun checkUserStatus() {
        val currentUser = auth.currentUser
        progressBar.visibility = View.GONE

        Log.d(TAG, "Checking user status, currentUser: ${currentUser?.uid ?: "null"}")

        if (currentUser != null) {
            Log.d(TAG, "User is logged in, checking Firestore for verification status: ${currentUser.email}")
            // User is logged in, check verification status in Firestore
            db.collection("users").document(currentUser.uid).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val verified = document.getBoolean("verified") ?: false
                        val stepCompleted = document.getLong("stepCompleted")?.toInt() ?: 1
                        Log.d(TAG, "Firestore data - verified: $verified, stepCompleted: $stepCompleted")

                        if (verified) {
                            Log.d(TAG, "User is verified, redirecting to HomeActivity")
                            startActivity(Intent(this, HomeActivity::class.java))
                        } else {
                            Log.d(TAG, "User is not verified, redirecting based on stepCompleted: $stepCompleted")
                            // Redirect based on stepCompleted
                            val intent = when (stepCompleted) {
                                1 -> Intent(this, EmailVerificationActivity::class.java)
                                2 -> Intent(this, CurrentAddressActivity::class.java)
                                3 -> Intent(this, AdminApprovalActivity::class.java)
                                else -> {
                                    Log.w(TAG, "Invalid stepCompleted value, defaulting to EmailVerificationActivity")
                                    Intent(this, EmailVerificationActivity::class.java)
                                }
                            }
                            startActivity(intent)
                        }
                    } else {
                        Log.w(TAG, "User document not found in Firestore, redirecting to MainMenuActivity")
                        startActivity(Intent(this, MainMenuActivity::class.java))
                    }
                    finish()
                }
                .addOnFailureListener { exception ->
                    Log.e(TAG, "Failed to fetch Firestore user data: ${exception.message}")
                    // Failed to fetch user data, redirect to MainMenuActivity
                    startActivity(Intent(this, MainMenuActivity::class.java))
                    finish()
                }
        } else {
            Log.d(TAG, "No user logged in, redirecting to MainMenuActivity")
            // User is not logged in, go to MainMenuActivity
            startActivity(Intent(this, MainMenuActivity::class.java))
            finish()
        }
    }
}