package com.aorv.blazerider

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.aorv.blazerider.databinding.FragmentNotificationsBinding
import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.firestore.Query

class NotificationsFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: NotificationsAdapter
    private val notificationsList = mutableListOf<Notification>()
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        fetchNotifications()
        setupMarkAllReadButton()
    }

    private fun setupRecyclerView() {
        adapter = NotificationsAdapter(notificationsList)
        binding.notificationsRecyclerView.layoutManager = LinearLayoutManager(context)
        binding.notificationsRecyclerView.adapter = adapter
    }

    private fun fetchNotifications() {
        val currentUserId = auth.currentUser?.uid ?: return
        db.collection("users").document(currentUserId).collection("notifications")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.e("NotificationsFragment", "Error fetching notifications: $e")
                    return@addSnapshotListener
                }
                notificationsList.clear()
                if (snapshot != null && !snapshot.isEmpty) {
                    for (doc in snapshot.documents) {
                        // Manually extract isRead to handle non-boolean values
                        val isReadRaw = doc.get("isRead")
                        val isRead = when (isReadRaw) {
                            is Boolean -> isReadRaw
                            is String -> isReadRaw.toBooleanStrictOrNull() ?: false
                            else -> false // Default if null or invalid type
                        }
                        Log.d("NotificationsFragment", "Raw isRead: $isReadRaw, Type: ${isReadRaw?.javaClass?.simpleName}, Parsed: $isRead")

                        val notification = try {
                            val baseNotification = doc.toObject(Notification::class.java)?.copy(documentId = doc.id)
                            baseNotification?.copy(isRead = isRead) // Override isRead
                        } catch (e: Exception) {
                            Log.e("NotificationsFragment", "Deserialization error: $e")
                            null
                        }
                        notification?.let {
                            Log.d("NotificationsFragment", "Deserialized: Message: ${it.message}, isRead: ${it.isRead}")
                            notificationsList.add(it)
                        }
                    }
                    binding.notificationsRecyclerView.visibility = View.VISIBLE
                    binding.noNotificationsText.visibility = View.GONE
                } else {
                    binding.notificationsRecyclerView.visibility = View.GONE
                    binding.noNotificationsText.visibility = View.VISIBLE
                }
                adapter.notifyDataSetChanged()
            }
    }

    private fun setupMarkAllReadButton() {
        binding.markAllReadButton.setOnClickListener {
            val currentUserId = auth.currentUser?.uid ?: return@setOnClickListener
            val batch = db.batch()
            notificationsList.filter { !it.isRead }.forEach { notification ->
                val docRef = db.collection("users").document(currentUserId)
                    .collection("notifications").document(notification.documentId)
                batch.update(docRef, "isRead", true, "updatedAt", Timestamp.now())
            }
            batch.commit().addOnSuccessListener {
                notificationsList.forEachIndexed { index, notification ->
                    if (!notification.isRead) {
                        notificationsList[index] = notification.copy(
                            isRead = true,
                            updatedAt = Timestamp.now()
                        )
                    }
                }
                adapter.notifyDataSetChanged()
            }.addOnFailureListener { e ->
                Log.e("NotificationsFragment", "Failed to mark all as read: $e")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
