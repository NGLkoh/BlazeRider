package com.aorv.blazerider

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.*

class ChatThreadAdapter(private val onChatClick: (Chat) -> Unit) : RecyclerView.Adapter<ChatThreadAdapter.ViewHolder>() {
    private val chats = mutableListOf<Chat>()

    class ViewHolder(itemView: View, private val onClick: (Chat) -> Unit) : RecyclerView.ViewHolder(itemView) {
        private val chatName: TextView = itemView.findViewById(R.id.chat_name)
        private val chatImage: ImageView = itemView.findViewById(R.id.chat_image)
        private val chatLastMessage: TextView = itemView.findViewById(R.id.chat_last_message)
        private val chatTimestamp: TextView = itemView.findViewById(R.id.chat_timestamp)

        fun bind(chat: Chat) {
            // Bind chat name
            chatName.text = chat.name.ifEmpty { "Unknown User" }

            // Bind last message
            chatLastMessage.text = chat.lastMessage ?: "No messages yet"

            // Bind timestamp (lastMessageTimestamp)
            chatTimestamp.text = chat.lastMessageTimestamp?.let { formatTimestamp(it) } ?: ""

            // Bind profile image
            Glide.with(chatImage.context)
                .load(chat.profileImage)
                .placeholder(R.drawable.ic_anonymous)
                .error(R.drawable.ic_anonymous)
                .into(chatImage)

            // Set click listener
            itemView.setOnClickListener { onClick(chat) }
        }

        private fun formatTimestamp(timestamp: Timestamp): String {
            val now = Calendar.getInstance()
            val messageTime = Calendar.getInstance().apply { time = timestamp.toDate() }

            val isSameDay = now.get(Calendar.DAY_OF_YEAR) == messageTime.get(Calendar.DAY_OF_YEAR) &&
                    now.get(Calendar.YEAR) == messageTime.get(Calendar.YEAR)
            val isSameYear = now.get(Calendar.YEAR) == messageTime.get(Calendar.YEAR)
            val daysDiff = (now.timeInMillis - messageTime.timeInMillis) / (1000 * 60 * 60 * 24)

            return when {
                isSameDay -> SimpleDateFormat("hh:mm a", Locale.getDefault()).format(timestamp.toDate())
                daysDiff <= 7 -> SimpleDateFormat("EEE", Locale.getDefault()).format(timestamp.toDate())
                isSameYear -> SimpleDateFormat("MMM dd", Locale.getDefault()).format(timestamp.toDate())
                else -> SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(timestamp.toDate())
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_chat_thread, parent, false)
        return ViewHolder(view, onChatClick)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(chats[position])
    }

    override fun getItemCount(): Int = chats.size

    fun updateChats(newChats: List<Chat>) {
        chats.clear()
        chats.addAll(newChats)
        notifyDataSetChanged()
    }
}