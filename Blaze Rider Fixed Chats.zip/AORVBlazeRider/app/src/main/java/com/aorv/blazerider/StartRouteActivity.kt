package com.aorv.blazerider

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import java.util.Locale

class StartRouteActivity : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnCameraMoveListener {

    private lateinit var map: GoogleMap
    private lateinit var directionStep: TextView
    private lateinit var nextDirection: TextView
    private lateinit var travelTime: TextView
    private lateinit var travelDistanceTime: TextView
    private lateinit var exitButton: ImageButton
    private lateinit var compassButton: ImageButton
    private lateinit var directionsCard: LinearLayout
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var tts: TextToSpeech
    private var instructionList: List<String> = emptyList()
    private var maneuverPoints: List<LatLng> = emptyList()
    private var currentStepIndex: Int = 0
    private val MANEUVER_THRESHOLD_METERS = 20.0
    private var polylinePoints: List<LatLng> = emptyList()
    private var passedPolylines: MutableList<Polyline> = mutableListOf()
    private var remainingPolylines: MutableList<Polyline> = mutableListOf()
    private var userMarker: Marker? = null
    private var isFirstLocationUpdate = true
    private var cachedMarkerBitmap: Bitmap? = null
    private var lastZoom: Float = -1f
    private var lastTilt: Float = -1f
    private var lastBearing: Float = -1f

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            enableMyLocation()
        } else {
            Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start_route)

        window.statusBarColor = ContextCompat.getColor(this, R.color.red_orange)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.US
                tts.setPitch(1.0f)
                tts.setSpeechRate(1.0f)
            } else {
                Toast.makeText(this, "Text-to-Speech initialization failed", Toast.LENGTH_SHORT).show()
            }
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                val location = locationResult.lastLocation ?: return
                val userLatLng = LatLng(location.latitude, location.longitude)
                updateUserMarker(userLatLng, location.bearing)
                updateManeuverIfNeeded(userLatLng)
                if (isFirstLocationUpdate) {
                    map.animateCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 15f))
                    isFirstLocationUpdate = false
                }
            }
        }

        directionsCard = findViewById(R.id.directionsCard)
        directionStep = findViewById(R.id.directionStep)
        nextDirection = findViewById(R.id.nextDirection)
        travelTime = findViewById(R.id.travelTime)
        travelDistanceTime = findViewById(R.id.travelDistanceTime)
        exitButton = findViewById(R.id.exitButton)
        compassButton = findViewById(R.id.compassButton)

        exitButton.setOnClickListener {
            finish()
        }

        compassButton.setOnClickListener {
            map.animateCamera(CameraUpdateFactory.newCameraPosition(
                com.google.android.gms.maps.model.CameraPosition.Builder()
                    .target(map.cameraPosition.target)
                    .zoom(map.cameraPosition.zoom)
                    .bearing(0f)
                    .tilt(map.cameraPosition.tilt)
                    .build()
            ))
            compassButton.rotation = 0f // Reset compass rotation
        }

        ViewCompat.setOnApplyWindowInsetsListener(directionsCard) { view, insets ->
            val statusBarHeight = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(0, statusBarHeight + 16, 0, 16)
            insets
        }

        val bottomInfo = findViewById<ConstraintLayout>(R.id.bottomInfo)
        ViewCompat.setOnApplyWindowInsetsListener(bottomInfo) { view, insets ->
            val navBarHeight = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            view.setPadding(0, 0, 0, navBarHeight + 16)
            insets
        }

        directionsCard.setOnClickListener {
            if (::tts.isInitialized && directionStep.text.isNotEmpty()) {
                tts.speak(directionStep.text, TextToSpeech.QUEUE_FLUSH, null, null)
            }
        }

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val instructions = intent.getStringExtra("instructions") ?: ""
        val duration = intent.getStringExtra("duration") ?: ""
        val distance = intent.getStringExtra("distance") ?: ""
        val eta = intent.getStringExtra("eta") ?: ""
        val polyline = intent.getStringExtra("polyline") ?: ""

        travelTime.text = duration
        travelDistanceTime.text = "$distance • $eta"

        instructionList = instructions.split("\n").filter { it.isNotBlank() }
        maneuverPoints = polyline.split("|").mapNotNull {
            val coords = it.split(",")
            if (coords.size == 2) {
                try {
                    LatLng(coords[0].toDouble(), coords[1].toDouble())
                } catch (e: NumberFormatException) {
                    null
                }
            } else {
                null
            }
        }.take(instructionList.size)

        polylinePoints = polyline.split("|").mapNotNull {
            val coords = it.split(",")
            if (coords.size == 2) {
                try {
                    LatLng(coords[0].toDouble(), coords[1].toDouble())
                } catch (e: NumberFormatException) {
                    null
                }
            } else {
                null
            }
        }

        updateDirectionsUI()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.uiSettings.isMyLocationButtonEnabled = false
        map.uiSettings.isCompassEnabled = false // Disable built-in compass

        // Set camera move listener to update compass rotation and marker
        map.setOnCameraMoveListener(this)

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            enableMyLocation()
        } else {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (polylinePoints.isNotEmpty()) {
            map.addCircle(
                CircleOptions()
                    .center(polylinePoints.first())
                    .radius(10.0)
                    .fillColor(Color.LTGRAY)
                    .strokeColor(Color.GRAY)
                    .strokeWidth(2f)
            )

            remainingPolylines.add(
                map.addPolyline(
                    PolylineOptions()
                        .addAll(polylinePoints)
                        .color(Color.BLUE)
                        .width(10f)
                )
            )
        }
    }

    override fun onCameraMove() {
        // Rotate compass opposite to map bearing
        compassButton.rotation = -map.cameraPosition.bearing
        // Update marker to reflect new zoom or tilt
        if (::map.isInitialized && userMarker != null) {
            val userLatLng = userMarker!!.position
            updateUserMarker(userLatLng, lastBearing)
        }
    }

    private fun enableMyLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        map.isMyLocationEnabled = false

        val locationRequest = LocationRequest.create().apply {
            interval = 5000
            fastestInterval = 2000
            priority = Priority.PRIORITY_HIGH_ACCURACY
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())
    }

    private fun updateUserMarker(userLatLng: LatLng, bearing: Float) {
        userMarker?.remove()

        // Calculate bitmap size based on zoom level (mimics Google Maps scaling)
        val zoom = if (::map.isInitialized) map.cameraPosition.zoom else 15f
        val baseSize = 96f // Base size in pixels at zoom 15
        val zoomScale = (zoom / 15f).coerceIn(0.5f, 2.0f) // Scale between 0.5x and 2x
        val bitmapSize = (baseSize * zoomScale).toInt().coerceAtLeast(48) // Minimum 48px
        val center = bitmapSize / 2f

        // Get tilt for 3D effect
        val tilt = if (::map.isInitialized) map.cameraPosition.tilt else 0f

        // Create or reuse bitmap if zoom/tilt/bearing unchanged
        if (cachedMarkerBitmap == null || zoom != lastZoom || tilt != lastTilt || bearing != lastBearing) {
            val bitmap = Bitmap.createBitmap(bitmapSize, bitmapSize, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            // Draw white circle background
            val circlePaint = Paint().apply {
                color = Color.WHITE
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            canvas.drawCircle(center, center, center * 0.8f, circlePaint) // Circle radius 80% of bitmap

            // Draw blue arrow
            val arrowPaint = Paint().apply {
                color = Color.BLUE
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            val path = Path()
            val arrowScale = center * 0.5f // Arrow size 50% of bitmap for larger appearance
            canvas.save()
            // Apply bearing rotation
            canvas.rotate(bearing, center, center)
            // Apply tilt transformation for 3D effect
            val matrix = Matrix()
            matrix.postRotate(bearing, center, center)
            matrix.postScale(1f, Math.cos(Math.toRadians(tilt.toDouble())).toFloat(), center, center)
            canvas.concat(matrix)
            canvas.translate(center, center) // Center the arrow
            path.moveTo(0f, -arrowScale) // Top
            path.lineTo(arrowScale * 0.5f, arrowScale * 0.5f) // Bottom right
            path.lineTo(0f, arrowScale * 0.3f) // Bottom center
            path.lineTo(-arrowScale * 0.5f, arrowScale * 0.5f) // Bottom left
            path.close()
            canvas.drawPath(path, arrowPaint)
            canvas.restore()

            cachedMarkerBitmap = bitmap
            lastZoom = zoom
            lastTilt = tilt
            lastBearing = bearing
        }

        val markerIcon = BitmapDescriptorFactory.fromBitmap(cachedMarkerBitmap!!)

        userMarker = map.addMarker(
            MarkerOptions()
                .position(userLatLng)
                .icon(markerIcon)
                .anchor(0.5f, 0.5f) // Center the marker
                .zIndex(1f)
        )
    }

    private fun updateManeuverIfNeeded(userLatLng: LatLng) {
        if (currentStepIndex >= maneuverPoints.size || currentStepIndex >= instructionList.size) return

        val maneuverPoint = maneuverPoints[currentStepIndex]
        val distance = calculateDistance(userLatLng, maneuverPoint)

        if (distance < MANEUVER_THRESHOLD_METERS) {
            updatePolylines()
            currentStepIndex++
            updateDirectionsUI()
        }
    }

    private fun updatePolylines() {
        passedPolylines.forEach { it.remove() }
        remainingPolylines.forEach { it.remove() }
        passedPolylines.clear()
        remainingPolylines.clear()

        val currentManeuverPoint = maneuverPoints.getOrNull(currentStepIndex)
        val passedPoints = if (currentManeuverPoint != null) {
            polylinePoints.takeWhile { it != currentManeuverPoint } + listOf(currentManeuverPoint)
        } else {
            emptyList()
        }.filterNotNull()
        val remainingPoints = if (currentManeuverPoint != null) {
            polylinePoints.dropWhile { it != currentManeuverPoint }
        } else {
            polylinePoints
        }.filterNotNull()

        if (passedPoints.size >= 2) {
            passedPolylines.add(
                map.addPolyline(
                    PolylineOptions()
                        .addAll(passedPoints)
                        .color(Color.LTGRAY)
                        .width(10f)
                )
            )
        }

        if (remainingPoints.size >= 2) {
            remainingPolylines.add(
                map.addPolyline(
                    PolylineOptions()
                        .addAll(remainingPoints)
                        .color(Color.BLUE)
                        .width(10f)
                )
            )
        }
    }

    private fun updateDirectionsUI() {
        if (currentStepIndex < instructionList.size) {
            directionStep.text = instructionList[currentStepIndex]
            nextDirection.text = if (currentStepIndex + 1 < instructionList.size) {
                "Then: ${instructionList[currentStepIndex + 1]}"
            } else {
                ""
            }
            if (::tts.isInitialized) {
                tts.speak(instructionList[currentStepIndex], TextToSpeech.QUEUE_FLUSH, null, null)
            }
        } else {
            directionStep.text = "You have arrived at your destination"
            nextDirection.text = ""
            if (::tts.isInitialized) {
                tts.speak("You have arrived at your destination", TextToSpeech.QUEUE_FLUSH, null, null)
            }
            remainingPolylines.forEach { it.remove() }
            remainingPolylines.clear()
        }
    }

    private fun calculateDistance(latLng1: LatLng, latLng2: LatLng): Double {
        val earthRadius = 6371000.0
        val lat1 = Math.toRadians(latLng1.latitude)
        val lat2 = Math.toRadians(latLng2.latitude)
        val deltaLat = Math.toRadians(latLng2.latitude - latLng1.latitude)
        val deltaLon = Math.toRadians(latLng2.longitude - latLng1.longitude)

        val a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
                Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return earthRadius * c
    }

    override fun onPause() {
        super.onPause()
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        userMarker?.remove()
        cachedMarkerBitmap = null
        super.onDestroy()
    }
}