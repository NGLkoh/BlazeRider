package com.aorv.blazerider

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SignInActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val btnSignIn = findViewById<Button>(R.id.btnSignIn)
        val scrollView = findViewById<ScrollView>(R.id.scrollView)

        // Back button
        findViewById<ImageButton>(R.id.backButton).setOnClickListener {
            finish()
        }

        // Sign in
        btnSignIn.setOnClickListener {
            val emailText = email.text.toString().trim()
            val pwd = password.text.toString().trim()

            if (emailText.isEmpty() || pwd.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            auth.signInWithEmailAndPassword(emailText, pwd)
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid ?: return@addOnSuccessListener

                    // Check user data in Firestore
                    db.collection("users").document(uid).get()
                        .addOnSuccessListener { document ->
                            if (document.exists()) {
                                val verified = document.getBoolean("verified") ?: false
                                val stepCompleted = document.getLong("stepCompleted")?.toInt() ?: 1

                                if (verified) {
                                    // User is verified, proceed to HomeActivity
                                    startActivity(Intent(this, HomeActivity::class.java))
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
                                    finish()
                                } else {
                                    // Redirect based on stepCompleted
                                    val intent = when (stepCompleted) {
                                        1 -> Intent(this, EmailVerificationActivity::class.java)
                                        2 -> Intent(this, CurrentAddressActivity::class.java)
                                        3 -> Intent(this, AdminApprovalActivity::class.java)
                                        else -> Intent(this, EmailVerificationActivity::class.java) // Default to EmailVerification
                                    }
                                    startActivity(intent)
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
                                    finish()
                                }
                            } else {
                                Toast.makeText(this, "User data not found.", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "Failed to fetch user data: ${it.message}", Toast.LENGTH_SHORT).show()
                        }
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(this, "Sign-in failed: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }
}