package com.aorv.blazerider

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.aorv.blazerider.R

class JoinedUsersBottomSheetFragment : BottomSheetDialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.bottom_sheet_joined_users, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Get the bottom sheet view
        val bottomSheet = view.findViewById<View>(R.id.bottom_sheet_content)
            ?: return // Avoid crash if view is not found

        val behavior = BottomSheetBehavior.from(bottomSheet)

        // Set peek height (convert 100dp to pixels for density independence)
        val density = resources.displayMetrics.density
        behavior.peekHeight = (100 * density).toInt() // 100dp

        // Set max height to half the screen height
        val halfScreenHeight = (resources.displayMetrics.heightPixels * 0.5).toInt()
        behavior.maxHeight = halfScreenHeight

        // Configure MD3 behavior
        behavior.state = BottomSheetBehavior.STATE_COLLAPSED
        behavior.isHideable = false // Prevent hiding the bottom sheet
        behavior.isFitToContents = false // Ensure maxHeight is respected
        behavior.expandedOffset = 0 // No offset at the top when expanded
    }
}