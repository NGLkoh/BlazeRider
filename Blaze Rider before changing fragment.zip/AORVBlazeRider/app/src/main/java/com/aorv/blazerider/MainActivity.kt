package com.aorv.blazerider

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DatabaseReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import java.util.Timer
import kotlin.concurrent.timerTask

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var rtdb: FirebaseDatabase
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var progressBar: ProgressBar
    private var userStatusRef: DatabaseReference? = null
    private var locationCallback: LocationCallback? = null
    private var lastKnownLocation: Location? = null // Track last significant location
    private var lastUpdate: Long = 0 // For debouncing Firestore updates
    private val LOCATION_PERMISSION_REQUEST_CODE = 1001
    private val TAG = "MainActivity"
    private val MIN_DISTANCE_CHANGE = 10.0f // 10 meters threshold
    private val LOCATION_UPDATE_INTERVAL = 5000L // 5 seconds

    companion object {
        private var hasCheckedUserStatus = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Initialize Firebase and Location
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        rtdb = FirebaseDatabase.getInstance()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Setup ProgressBar
        progressBar = findViewById<ProgressBar>(R.id.loadingProgressBar).apply {
            visibility = View.VISIBLE
            isIndeterminate = true
            indeterminateDrawable.setColorFilter(
                resources.getColor(android.R.color.holo_red_dark),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Add lifecycle observer for app foreground/background events
        val lifecycleObserver = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> onAppForegrounded()
                Lifecycle.Event.ON_STOP -> onAppBackgrounded()
                else -> { /* No action needed */ }
            }
        }
        lifecycle.addObserver(lifecycleObserver)

        // Check user status
        if (savedInstanceState == null && !hasCheckedUserStatus) {
            Log.d(TAG, "Fresh app launch, scheduling checkUserStatus")
            hasCheckedUserStatus = true
            Timer().schedule(timerTask {
                runOnUiThread {
                    checkUserStatus()
                }
            }, 1000)
        } else {
            Log.d(TAG, "Not a fresh launch or checkUserStatus already ran, redirecting to MainMenuActivity")
            progressBar.visibility = View.GONE
            startActivity(Intent(this, MainMenuActivity::class.java))
            finish()
        }
    }

    private fun checkUserStatus() {
        val currentUser = auth.currentUser
        progressBar.visibility = View.GONE

        Log.d(TAG, "Checking user status, currentUser: ${currentUser?.uid ?: "null"}")

        if (currentUser != null) {
            Log.d(TAG, "User is logged in, checking Firestore for verification status: ${currentUser.email}")
            db.collection("users").document(currentUser.uid).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val verified = document.getBoolean("verified") ?: false
                        val stepCompleted = document.getLong("stepCompleted")?.toInt() ?: 1
                        Log.d(TAG, "Firestore data - verified: $verified, stepCompleted: $stepCompleted")

                        // Setup presence and location after verification check
                        setupPresenceAndLocation(currentUser.uid)

                        if (verified) {
                            Log.d(TAG, "User is verified, redirecting to HomeActivity")
                            startActivity(Intent(this, HomeActivity::class.java))
                        } else {
                            Log.d(TAG, "User is not verified, redirecting based on stepCompleted: $stepCompleted")
                            val intent = when (stepCompleted) {
                                1 -> Intent(this, EmailVerificationActivity::class.java)
                                2 -> Intent(this, CurrentAddressActivity::class.java)
                                3 -> Intent(this, AdminApprovalActivity::class.java)
                                else -> {
                                    Log.w(TAG, "Invalid stepCompleted value, defaulting to EmailVerificationActivity")
                                    Intent(this, EmailVerificationActivity::class.java)
                                }
                            }
                            startActivity(intent)
                        }
                    } else {
                        Log.w(TAG, "User document not found in Firestore, creating document")
                        createUserDocument(currentUser.uid, currentUser.email, currentUser.displayName)
                        startActivity(Intent(this, MainMenuActivity::class.java))
                    }
                    finish()
                }
                .addOnFailureListener { exception ->
                    Log.e(TAG, "Failed to fetch Firestore user data: ${exception.message}")
                    startActivity(Intent(this, MainMenuActivity::class.java))
                    finish()
                }
        } else {
            Log.d(TAG, "No user logged in, redirecting to MainMenuActivity")
            startActivity(Intent(this, MainMenuActivity::class.java))
            finish()
        }
    }

    private fun createUserDocument(userId: String, email: String?, displayName: String?) {
        db.collection("users").document(userId).set(
            mapOf(
                "displayName" to (displayName ?: ""),
                "email" to (email ?: ""),
                "verified" to false,
                "stepCompleted" to 1,
                "lastActive" to FieldValue.serverTimestamp()
            ),
            com.google.firebase.firestore.SetOptions.merge()
        ).addOnFailureListener { e ->
            Log.e(TAG, "Failed to create user document: ${e.message}")
        }
    }

    private fun checkLocationPermissions(): Boolean {
        return ActivityCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun isGpsEnabled(): Boolean {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun requestLocationPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            auth.currentUser?.let { setupPresenceAndLocation(it.uid) }
        } else {
            auth.currentUser?.let { setupPresenceAndLocation(it.uid, useLocation = false) }
        }
    }

    private fun updateUserStatus(
        userId: String,
        state: String,
        latitude: Double,
        longitude: Double,
        onComplete: (latitude: Double, longitude: Double) -> Unit = { _, _ -> }
    ) {
        val status = mapOf(
            "state" to state,
            "lastActive" to System.currentTimeMillis(),
            "location" to mapOf(
                "latitude" to latitude,
                "longitude" to longitude
            )
        )
        userStatusRef?.setValue(status)?.addOnFailureListener { e ->
            Log.e(TAG, "Failed to update Realtime Database: ${e.message}")
        }
        updateFirestoreLastActive(userId)
        onComplete(latitude, longitude)
    }

    private fun startLocationUpdates(userId: String) {
        if (checkLocationPermissions() && isGpsEnabled()) {
            val locationRequest = LocationRequest.create().apply {
                interval = LOCATION_UPDATE_INTERVAL
                fastestInterval = LOCATION_UPDATE_INTERVAL / 2
                priority = LocationRequest.PRIORITY_HIGH_ACCURACY
            }
            try {
                locationCallback = object : LocationCallback() {
                    override fun onLocationResult(result: LocationResult) {
                        result.lastLocation?.let { newLocation ->
                            // Check for significant change
                            val isSignificantChange = lastKnownLocation?.let { last ->
                                val distance = FloatArray(1)
                                Location.distanceBetween(
                                    last.latitude, last.longitude,
                                    newLocation.latitude, newLocation.longitude,
                                    distance
                                )
                                distance[0] > MIN_DISTANCE_CHANGE
                            } ?: true // Update if no previous location

                            if (isSignificantChange) {
                                lastKnownLocation = newLocation
                                updateUserStatus(
                                    userId,
                                    "online",
                                    newLocation.latitude,
                                    newLocation.longitude
                                ) { latitude, longitude ->
                                    userStatusRef?.onDisconnect()?.setValue(
                                        mapOf(
                                            "state" to "offline",
                                            "lastActive" to System.currentTimeMillis(),
                                            "location" to mapOf(
                                                "latitude" to latitude,
                                                "longitude" to longitude
                                            )
                                        )
                                    )?.addOnFailureListener { e ->
                                        Log.e(TAG, "Failed to set onDisconnect: ${e.message}")
                                    }
                                }
                            }
                        }
                    }
                }
                locationCallback?.let {
                    fusedLocationClient.requestLocationUpdates(locationRequest, it, mainLooper)
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException starting location updates: ${e.message}")
                // Use last known location or default
                val latitude = lastKnownLocation?.latitude ?: 0.0
                val longitude = lastKnownLocation?.longitude ?: 0.0
                updateUserStatus(userId, "online", latitude, longitude)
            }
        } else {
            // Use last known location or default
            val latitude = lastKnownLocation?.latitude ?: 0.0
            val longitude = lastKnownLocation?.longitude ?: 0.0
            updateUserStatus(userId, "pending", latitude, longitude)
        }
    }

    private fun stopLocationUpdates() {
        locationCallback?.let {
            fusedLocationClient.removeLocationUpdates(it)
            locationCallback = null
        }
    }

    private fun setupPresenceAndLocation(userId: String, useLocation: Boolean = true) {
        userStatusRef = rtdb.reference.child("status").child(userId)
        val connectedRef = rtdb.reference.child(".info/connected")
        connectedRef.addValueEventListener(object : com.google.firebase.database.ValueEventListener {
            override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                if (snapshot.getValue(Boolean::class.java) == true) {
                    if (useLocation && checkLocationPermissions() && isGpsEnabled()) {
                        startLocationUpdates(userId)
                    } else {
                        // Use last known location or default
                        val latitude = lastKnownLocation?.latitude ?: 0.0
                        val longitude = lastKnownLocation?.longitude ?: 0.0
                        updateUserStatus(userId, "pending", latitude, longitude)
                    }
                } else {
                    stopLocationUpdates()
                }
            }

            override fun onCancelled(error: com.google.firebase.database.DatabaseError) {
                Log.e(TAG, "Realtime Database error: ${error.message}")
            }
        })

        // Initialize status with last known location or default
        if (!checkLocationPermissions() || !isGpsEnabled()) {
            val latitude = lastKnownLocation?.latitude ?: 0.0
            val longitude = lastKnownLocation?.longitude ?: 0.0
            updateUserStatus(userId, "pending", latitude, longitude)
        }
    }

    private fun updateFirestoreLastActive(userId: String) {
        if (System.currentTimeMillis() - lastUpdate > 5 * 60 * 1000) {
            lastUpdate = System.currentTimeMillis()
            db.collection("users").document(userId)
                .update("lastActive", FieldValue.serverTimestamp())
                .addOnFailureListener { e ->
                    Log.e(TAG, "Failed to update Firestore lastActive: ${e.message}")
                }
        }
    }

    private fun onAppForegrounded() {
        auth.currentUser?.let { user ->
            userStatusRef?.let {
                if (checkLocationPermissions() && isGpsEnabled()) {
                    startLocationUpdates(user.uid)
                } else {
                    // Use last known location or default
                    val latitude = lastKnownLocation?.latitude ?: 0.0
                    val longitude = lastKnownLocation?.longitude ?: 0.0
                    updateUserStatus(user.uid, "pending", latitude, longitude)
                }
            }
        }
    }

    private fun onAppBackgrounded() {
        stopLocationUpdates()
        auth.currentUser?.let { user ->
            userStatusRef?.let {
                // Use last known location or default
                val latitude = lastKnownLocation?.latitude ?: 0.0
                val longitude = lastKnownLocation?.longitude ?: 0.0
                updateUserStatus(user.uid, "offline", latitude, longitude)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopLocationUpdates()
    }
}