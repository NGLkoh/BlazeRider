package com.aorv.blazerider

import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

// Data class for Message, matching updated Firebase structure
data class Message(
    val id: String,
    val senderId: String,
    val content: String,
    val timestamp: Timestamp,
    val type: String,
    val readBy: List<String>,
    val showDivider: Boolean = false
)

class MessageAdapter(
    private val currentUserId: String,
    private val chatId: String,
    private val db: FirebaseFirestore
) : ListAdapter<Message, MessageViewHolder>(MessageDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view, db, chatId)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = getItem(position)
        holder.bind(message, currentUserId)
    }
}

class MessageViewHolder(
    itemView: View,
    private val db: FirebaseFirestore,
    private val chatId: String
) : RecyclerView.ViewHolder(itemView) {
    private val senderName: TextView = itemView.findViewById(R.id.sender_name)
    private val messageText: TextView = itemView.findViewById(R.id.message_text)
    private val timestampText: TextView = itemView.findViewById(R.id.timestamp)
    private val messageContentWrapper: LinearLayout = itemView.findViewById(R.id.message_content_wrapper)
    private val timestampDivider: TextView = itemView.findViewById(R.id.timestamp_divider)
    private val messageImage: ImageView? = itemView.findViewById(R.id.message_image)

    fun bind(message: Message, currentUserId: String) {
        val isCurrentUser = message.senderId == currentUserId

        // Handle message content based on type
        when (message.type) {
            "text" -> {
                messageText.isVisible = true
                messageImage?.isVisible = false
                messageText.text = message.content
                messageText.setBackgroundResource(
                    if (isCurrentUser) R.drawable.rounded_message_background_self
                    else R.drawable.rounded_message_background_other
                )
                messageText.setOnClickListener {
                    timestampText.isVisible = !timestampText.isVisible
                }
            }
            "file" -> {
                messageText.isVisible = true
                messageImage?.isVisible = false
                messageText.text = "📎 File"
                messageText.setBackgroundResource(
                    if (isCurrentUser) R.drawable.rounded_message_background_self
                    else R.drawable.rounded_message_background_other
                )
                messageText.setOnClickListener {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(message.content))
                    try {
                        itemView.context.startActivity(intent)
                    } catch (e: Exception) {
                        Log.e("MessageViewHolder", "Failed to open file", e)
                        Toast.makeText(itemView.context, "Unable to open file", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            "image" -> {
                messageText.isVisible = false
                messageImage?.isVisible = true
                Glide.with(itemView.context)
                    .load(message.content)
                    .placeholder(R.drawable.ic_anonymous)
                    .error(R.drawable.ic_anonymous)
                    .into(messageImage!!)
                messageImage.setOnClickListener {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(message.content))
                    intent.setDataAndType(Uri.parse(message.content), "image/*")
                    try {
                        itemView.context.startActivity(intent)
                    } catch (e: Exception) {
                        Log.e("MessageViewHolder", "Failed to open image", e)
                        Toast.makeText(itemView.context, "Unable to open image", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        // Set text color based on sender
        messageText.setTextColor(
            ContextCompat.getColor(
                itemView.context,
                if (isCurrentUser) android.R.color.white else android.R.color.black
            )
        )

        // Format and set message timestamp (12-hour format)
        val dateFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
        timestampText.text = dateFormat.format(message.timestamp.toDate()) // Convert Timestamp to Date
        timestampText.isVisible = false // Hide timestamp by default

        // Toggle timestamp visibility on click (for text and file messages)
        if (message.type != "image") {
            messageContentWrapper.setOnClickListener {
                timestampText.isVisible = !timestampText.isVisible
            }
        } else {
            messageContentWrapper.setOnClickListener(null)
        }

        // Set divider visibility and text
        timestampDivider.isVisible = message.showDivider
        if (message.showDivider) {
            timestampDivider.text = formatDividerTimestamp(message.timestamp)
        }

        // Adjust layout based on sender
        val layoutParams = messageContentWrapper.layoutParams as LinearLayout.LayoutParams
        layoutParams.width = LinearLayout.LayoutParams.WRAP_CONTENT
        layoutParams.gravity = if (isCurrentUser) Gravity.END else Gravity.START
        messageContentWrapper.layoutParams = layoutParams

        // Adjust timestamp alignment
        val timestampParams = timestampText.layoutParams as LinearLayout.LayoutParams
        timestampParams.gravity = if (isCurrentUser) Gravity.END else Gravity.START
        timestampText.layoutParams = timestampParams

        // Set sender name (hidden for p2p chats unless desired)
        senderName.isVisible = false
        if (!isCurrentUser) {
            db.collection("users").document(message.senderId).get()
                .addOnSuccessListener { document ->
                    val name = document.getString("name") ?: "Unknown"
                    senderName.text = name
                    // Uncomment to show sender name in p2p chats
                    // senderName.isVisible = true
                }
                .addOnFailureListener { e ->
                    Log.e("MessageViewHolder", "Failed to fetch sender name", e)
                }
        }

        // Update readBy status if not already read by current user
        if (!isCurrentUser && !message.readBy.contains(currentUserId)) {
            val updatedReadBy = message.readBy + currentUserId
            db.collection("chats").document(chatId)
                .collection("messages").document(message.id)
                .update("readBy", updatedReadBy)
                .addOnSuccessListener {
                    db.collection("userChats").document(currentUserId)
                        .collection("chats").document(chatId)
                        .update("unreadCount", 0)
                }
                .addOnFailureListener { e ->
                    Log.e("MessageViewHolder", "Failed to update readBy", e)
                }
        }
    }

    private fun formatDividerTimestamp(timestamp: Timestamp): String {
        val now = Calendar.getInstance()
        val messageTime = Calendar.getInstance().apply { time = timestamp.toDate() } // Convert Timestamp to Date
        val timeDiff = now.timeInMillis - timestamp.toDate().time
        val oneDayMillis = 24 * 60 * 60 * 1000L
        val oneWeekMillis = 7 * oneDayMillis

        return when {
            // Less than a day, show time only
            timeDiff < oneDayMillis -> {
                val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
                "--- ${timeFormat.format(timestamp.toDate())} ---"
            }
            // Yesterday
            timeDiff < 2 * oneDayMillis && isYesterday(now, messageTime) -> {
                val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
                "--- Yesterday at ${timeFormat.format(timestamp.toDate())} ---"
            }
            // Within a week, show day of week
            timeDiff < oneWeekMillis -> {
                val dayFormat = SimpleDateFormat("EEE 'at' h:mm a", Locale.getDefault())
                "--- ${dayFormat.format(timestamp.toDate())} ---"
            }
            // More than a week, show month and day
            else -> {
                val dateFormat = SimpleDateFormat("MMM d 'at' h:mm a", Locale.getDefault())
                "--- ${dateFormat.format(timestamp.toDate())} ---"
            }
        }
    }

    private fun isYesterday(now: Calendar, messageTime: Calendar): Boolean {
        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        return messageTime.get(Calendar.DAY_OF_YEAR) == yesterday.get(Calendar.DAY_OF_YEAR) &&
                messageTime.get(Calendar.YEAR) == yesterday.get(Calendar.YEAR)
    }
}

class MessageDiffCallback : DiffUtil.ItemCallback<Message>() {
    override fun areItemsTheSame(oldItem: Message, newItem: Message): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Message, newItem: Message): Boolean {
        return oldItem == newItem
    }
}