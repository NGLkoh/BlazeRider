package com.aorv.blazerider

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.aorv.blazerider.databinding.ItemNotificationsBinding
import com.google.firebase.Timestamp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

class NotificationsAdapter(private val notifications: List<Notification>) :
    androidx.recyclerview.widget.RecyclerView.Adapter<NotificationsAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemNotificationsBinding) :
        androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemNotificationsBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val notification = notifications[position]
        with(holder.binding) {
            notificationContent.text = notification.message
            notificationTimestamp.text = notification.createdAt?.let { formatTimestamp(it) } ?: "Unknown"
            notificationProfilePic.setImageResource(
                if (notification.type == "weather") R.drawable.ic_blaze_rider else R.drawable.ic_anonymous
            )
            Log.d("NotificationsAdapter", "Binding: Message: ${notification.message}, isRead: ${notification.isRead}")
            root.setBackgroundResource(
                if (notification.isRead) R.color.white else R.color.light_red_orange
            )
            unreadIndicator.visibility = if (notification.isRead) View.GONE else View.VISIBLE
        }
    }

    override fun getItemCount(): Int = notifications.size

    private fun formatTimestamp(timestamp: Timestamp): String {
        val sdf = SimpleDateFormat("dd MMM yyyy 'at' hh:mm a", Locale.getDefault())
        return sdf.format(timestamp.toDate())
    }
}