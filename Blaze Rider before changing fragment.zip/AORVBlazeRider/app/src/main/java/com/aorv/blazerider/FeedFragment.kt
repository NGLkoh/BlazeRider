package com.aorv.blazerider

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.imageview.ShapeableImageView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.*

class FeedFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var postAdapter: PostAdapter
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private var postsListener: ListenerRegistration? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_feed, container, false)

        val whatsOnMindButton = view.findViewById<TextView>(R.id.btn_whats_on_mind)
        val addImageButton = view.findViewById<ImageButton>(R.id.btn_add_image)

        whatsOnMindButton.setOnClickListener {
            val intent = Intent(requireContext(), PostActivity::class.java)
            startActivity(intent)
        }
        addImageButton.setOnClickListener {
            val intent = Intent(requireContext(), PostActivity::class.java)
            startActivity(intent)
        }

        val chatButton = view.findViewById<ImageButton>(R.id.btn_chat)
        chatButton.setOnClickListener {
            val intent = Intent(requireContext(), MessagesActivity::class.java)
            startActivity(intent)
        }

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val mainContent = view.findViewById<LinearLayout>(R.id.main_content)
        ViewCompat.setOnApplyWindowInsetsListener(mainContent) { v, insets ->
            val navBarHeight = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, navBarHeight)
            insets
        }

        recyclerView = view.findViewById(R.id.feed_recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(context)
        postAdapter = PostAdapter()
        recyclerView.adapter = postAdapter

        val userImage = view.findViewById<ShapeableImageView>(R.id.user_image)
        loadUserProfile(userImage)

        loadPosts()
    }

    private fun loadUserProfile(userImage: ShapeableImageView) {
        val user = auth.currentUser
        if (user != null) {
            db.collection("users").document(user.uid).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val profileImageUrl = document.getString("profileImageUrl")
                        Glide.with(this)
                            .load(profileImageUrl)
                            .placeholder(R.drawable.ic_anonymous)
                            .error(R.drawable.ic_anonymous)
                            .into(userImage)
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FeedFragment", "Error loading user profile: ${e.message}")
                    Glide.with(this)
                        .load(R.drawable.ic_anonymous)
                        .into(userImage)
                }
        }
    }

    private fun loadPosts() {
        postsListener = db.collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.e("FeedFragment", "Error loading posts: ${e.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val posts = snapshot.documents.mapNotNull { doc ->
                        val imageUris = doc.get("imageUris") as? List<String> ?: emptyList()
                        Log.d("FeedFragment", "Post ID: ${doc.id}, Image URIs: $imageUris")
                        Post(
                            id = doc.id,
                            userId = doc.getString("userId") ?: "",
                            content = doc.getString("content") ?: "",
                            createdAt = doc.getTimestamp("createdAt")?.toDate(),
                            imageUris = imageUris,
                            reactionCount = doc.get("reactionCount") as? Map<String, Long> ?: emptyMap()
                        )
                    }
                    postAdapter.submitPosts(posts)
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        postsListener?.remove()
    }

    inner class PostAdapter : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

        private var posts = listOf<Post>()

        fun submitPosts(newPosts: List<Post>) {
            posts = newPosts
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false)
            return PostViewHolder(view)
        }

        override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
            holder.bind(posts[position])
        }

        override fun getItemCount(): Int = posts.size

        inner class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val profilePic = itemView.findViewById<ShapeableImageView>(R.id.post_profile_pic)
            private val userName = itemView.findViewById<TextView>(R.id.post_user_name)
            private val timestamp = itemView.findViewById<TextView>(R.id.post_timestamp)
            private val content = itemView.findViewById<TextView>(R.id.post_content)
            private val imageContainer = itemView.findViewById<ConstraintLayout>(R.id.post_image_container)
            private val imageViewPager = itemView.findViewById<ViewPager2>(R.id.post_image_view_pager)
            private val imageCounter = itemView.findViewById<TextView>(R.id.post_image_counter)
            private val likeIcon = itemView.findViewById<ImageView>(R.id.post_like_icon)
            private val likeText = itemView.findViewById<TextView>(R.id.post_like_text)
            private val commentContainer = itemView.findViewById<LinearLayout>(R.id.comment_container)
            private val shareContainer = itemView.findViewById<LinearLayout>(R.id.share_container)
            private val reactionsCount = itemView.findViewById<TextView>(R.id.post_reactions_count)

            private var reactionsListener: ListenerRegistration? = null
            private var pageChangeCallback: ViewPager2.OnPageChangeCallback? = null

            fun bind(post: Post) {
                // Cleanup previous listeners
                reactionsListener?.remove()
                pageChangeCallback?.let { imageViewPager.unregisterOnPageChangeCallback(it) }
                pageChangeCallback = null

                // Load user data
                db.collection("users").document(post.userId).get()
                    .addOnSuccessListener { document ->
                        if (document.exists()) {
                            val firstName = document.getString("firstName") ?: ""
                            val lastName = document.getString("lastName") ?: ""
                            userName.text = "$firstName $lastName".trim()
                            val profileImageUrl = document.getString("profileImageUrl")
                            Glide.with(itemView.context)
                                .load(profileImageUrl)
                                .placeholder(R.drawable.ic_anonymous)
                                .error(R.drawable.ic_anonymous)
                                .into(profilePic)
                        }
                    }
                    .addOnFailureListener { e ->
                        Log.e("PostViewHolder", "Error loading user data: ${e.message}")
                        Glide.with(itemView.context)
                            .load(R.drawable.ic_anonymous)
                            .into(profilePic)
                    }

                // Set post data
                content.text = post.content
                timestamp.text = post.createdAt?.let {
                    SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(it)
                } ?: ""

                // Setup images
                if (post.imageUris.isNotEmpty()) {
                    imageContainer.visibility = View.VISIBLE
                    imageViewPager.adapter = ImagePagerAdapter(post.imageUris)
                    imageViewPager.setCurrentItem(0, false)
                    // Set counter visibility and text
                    if (post.imageUris.size > 1) {
                        imageCounter.visibility = View.VISIBLE
                        imageCounter.text = "1/${post.imageUris.size}"
                        // Register page change callback
                        pageChangeCallback = object : ViewPager2.OnPageChangeCallback() {
                            override fun onPageSelected(position: Int) {
                                imageCounter.text = "${position + 1}/${post.imageUris.size}"
                            }
                        }
                        pageChangeCallback?.let { imageViewPager.registerOnPageChangeCallback(it) }
                    } else {
                        imageCounter.visibility = View.GONE
                    }
                } else {
                    imageContainer.visibility = View.GONE
                    imageCounter.visibility = View.GONE
                }

                // Setup reactions count listener
                reactionsListener = db.collection("posts").document(post.id)
                    .collection("reactions")
                    .addSnapshotListener { snapshot, e ->
                        if (e != null) {
                            Log.e("PostViewHolder", "Error loading reactions: ${e.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            val count = snapshot.size()
                            reactionsCount.text = when {
                                count > 0 -> "$count reactions"
                                else -> ""
                            }
                        }
                    }

                // Load current reaction
                val user = auth.currentUser
                if (user != null) {
                    db.collection("posts").document(post.id)
                        .collection("reactions").document(user.uid).get()
                        .addOnSuccessListener { document ->
                            val reactionType = document.getString("reactionType")
                            updateLikeIcon(reactionType)
                        }
                } else {
                    updateLikeIcon(null)
                }

                // Like action
                likeIcon.setOnClickListener {
                    val user = auth.currentUser ?: return@setOnClickListener
                    db.collection("posts").document(post.id)
                        .collection("reactions").document(user.uid).get()
                        .addOnSuccessListener { document ->
                            if (document.exists()) {
                                removeReaction(post.id)
                            } else {
                                updateReaction(post.id, "like")
                            }
                        }
                }

                likeIcon.setOnLongClickListener {
                    showReactionPicker(post.id)
                    true
                }

                // Comment action
                commentContainer.setOnClickListener {
                    val intent = Intent(itemView.context, CommentsActivity::class.java).apply {
                        putExtra("POST_ID", post.id)
                    }
                    itemView.context.startActivity(intent)
                }

                // Share action
                shareContainer.setOnClickListener {
                    // Implement share functionality
                }
            }

            private fun showReactionPicker(postId: String) {
                val inflater = LayoutInflater.from(itemView.context)
                val popupView = inflater.inflate(R.layout.layout_reaction_popup, null)
                val popupWindow = PopupWindow(
                    popupView,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    true
                )

                val reactions: Map<Int, String> = mapOf(
                    R.id.reaction_like to "like",
                    R.id.reaction_love to "love",
                    R.id.reaction_laugh to "haha",
                    R.id.reaction_wow to "wow",
                    R.id.reaction_sad to "sad",
                    R.id.reaction_angry to "angry"
                )

                reactions.forEach { (viewId: Int, reactionType: String) ->
                    popupView.findViewById<ImageView>(viewId).setOnClickListener {
                        updateReaction(postId, reactionType)
                        popupWindow.dismiss()
                    }
                }

                val location = IntArray(2)
                likeIcon.getLocationOnScreen(location)
                popupWindow.showAsDropDown(likeIcon, 0, -likeIcon.height - popupView.measuredHeight - 16)
            }

            private fun updateLikeIcon(reactionType: String?) {
                val (iconRes, text) = when (reactionType) {
                    "like" -> R.drawable.ic_fb_like to "Like"
                    "love" -> R.drawable.ic_fb_love to "Love"
                    "haha" -> R.drawable.ic_fb_laugh to "Haha"
                    "wow" -> R.drawable.ic_fb_wow to "Wow"
                    "sad" -> R.drawable.ic_fb_sad to "Sad"
                    "angry" -> R.drawable.ic_fb_angry to "Angry"
                    else -> R.drawable.ic_empty_like to "Like"
                }
                likeIcon.setImageResource(iconRes)
                likeText.text = text
                if (reactionType == null) {
                    likeIcon.setColorFilter(ContextCompat.getColor(itemView.context, R.color.teal_200))
                } else {
                    likeIcon.setColorFilter(null)
                }
            }

            private fun updateReaction(postId: String, reactionType: String) {
                val user = auth.currentUser ?: return
                val reactionRef = db.collection("posts").document(postId)
                    .collection("reactions").document(user.uid)

                db.runTransaction { transaction ->
                    val postRef = db.collection("posts").document(postId)
                    val post = transaction.get(postRef)
                    val currentReaction = transaction.get(reactionRef).getString("reactionType")
                    val reactionCount = post.get("reactionCount") as? Map<String, Long> ?: emptyMap()

                    transaction.set(reactionRef, mapOf(
                        "reactionType" to reactionType,
                        "timestamp" to FieldValue.serverTimestamp(),
                        "userId" to user.uid
                    ))

                    val updatedCount = reactionCount.toMutableMap()
                    if (currentReaction != null && currentReaction != reactionType) {
                        updatedCount[currentReaction] = (updatedCount[currentReaction] ?: 0) - 1
                        updatedCount[reactionType] = (updatedCount[reactionType] ?: 0) + 1
                    } else if (currentReaction == null) {
                        updatedCount[reactionType] = (updatedCount[reactionType] ?: 0) + 1
                    }
                    transaction.update(postRef, "reactionCount", updatedCount)
                }.addOnSuccessListener {
                    updateLikeIcon(reactionType)
                }
            }

            private fun removeReaction(postId: String) {
                val user = auth.currentUser ?: return
                val reactionRef = db.collection("posts").document(postId)
                    .collection("reactions").document(user.uid)

                db.runTransaction { transaction ->
                    val postRef = db.collection("posts").document(postId)
                    val post = transaction.get(postRef)
                    val currentReaction = transaction.get(reactionRef).getString("reactionType")
                    val reactionCount = post.get("reactionCount") as? Map<String, Long> ?: emptyMap()

                    transaction.delete(reactionRef)

                    if (currentReaction != null) {
                        val updatedCount = reactionCount.toMutableMap()
                        updatedCount[currentReaction] = (updatedCount[currentReaction] ?: 0) - 1
                        transaction.update(postRef, "reactionCount", updatedCount)
                    }
                }.addOnSuccessListener {
                    updateLikeIcon(null)
                }
            }
        }
    }

    inner class ImagePagerAdapter(private val imageUrls: List<String>) :
        RecyclerView.Adapter<ImagePagerAdapter.ViewHolder>() {

        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val imageView: ImageView = itemView.findViewById(android.R.id.icon)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val imageView = ImageView(parent.context).apply {
                id = android.R.id.icon
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            return ViewHolder(imageView)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            Glide.with(holder.imageView)
                .load(imageUrls[position])
                .placeholder(R.drawable.ic_error_image)
                .error(R.drawable.ic_error_image)
                .into(holder.imageView)
        }

        override fun getItemCount(): Int = imageUrls.size
    }
}