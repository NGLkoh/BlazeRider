package com.aorv.blazerider

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aorv.blazerider.databinding.ItemOwnRidesBinding
import com.bumptech.glide.Glide
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.storage.FirebaseStorage
import java.text.SimpleDateFormat
import java.util.Locale

data class OwnRide(
    val datetime: Timestamp? = null,
    val destination: String? = null,
    val destinationCoordinates: Map<String, Double>? = null,
    val distance: Double? = null,
    val duration: Double? = null,
    val origin: String? = null,
    val originCoordinates: Map<String, Double>? = null,
    val userUid: String? = null,
    val joinedRiders: Map<String, Map<String, Any>>? = null,
    val sharedRoutesId: String? = null
)

class MyRidesFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var noRidesText: TextView
    private lateinit var adapter: MyRidesAdapter
    private val ridesList = mutableListOf<OwnRide>()
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val storage = FirebaseStorage.getInstance()
    private var ridesListener: ListenerRegistration? = null
    private var profileImageUrl: String? = null
    private var riderName: String? = null
    private val TAG = "MyRidesFragment"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d(TAG, "onCreateView: Initializing MyRidesFragment")
        val view = inflater.inflate(R.layout.fragment_my_rides, container, false)

        recyclerView = view.findViewById(R.id.my_rides_recycler_view)
        noRidesText = view.findViewById(R.id.no_rides_text)
        recyclerView.layoutManager = LinearLayoutManager(context)
        adapter = MyRidesAdapter(ridesList)
        recyclerView.adapter = adapter
        Log.d(TAG, "onCreateView: RecyclerView and adapter initialized")

        fetchUserData()
        fetchMyRides()

        return view
    }

    private fun fetchUserData() {
        val currentUserUid = auth.currentUser?.uid
        if (currentUserUid == null) {
            Log.e(TAG, "fetchUserData: No user logged in")
            return
        }
        Log.d(TAG, "fetchUserData: Fetching user data for UID: $currentUserUid")
        db.collection("users").document(currentUserUid)
            .get()
            .addOnSuccessListener { document ->
                val user = document.toObject<User>()
                profileImageUrl = user?.profileImageUrl
                riderName = "${user?.firstName ?: ""} ${user?.lastName ?: ""}".trim()
                Log.d(TAG, "fetchUserData: Profile image URL: $profileImageUrl, Rider name: $riderName")
                adapter.notifyDataSetChanged() // Notify adapter to update with new user data
            }
            .addOnFailureListener { exception ->
                Log.e(TAG, "fetchUserData: Failed to fetch user data", exception)
            }
    }

    private fun fetchMyRides() {
        val currentUserUid = auth.currentUser?.uid
        if (currentUserUid == null) {
            Log.e(TAG, "fetchMyRides: No user logged in")
            return
        }
        Log.d(TAG, "fetchMyRides: Fetching rides for user UID: $currentUserUid")
        ridesListener = db.collection("sharedRoutes")
            .whereEqualTo("userUid", currentUserUid) // Use dynamic UID instead of hardcoded
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.e(TAG, "fetchMyRides: Error fetching rides", error)
                    return@addSnapshotListener
                }
                Log.d(TAG, "fetchMyRides: Received snapshot with ${snapshots?.size() ?: 0} documents")
                ridesList.clear()
                snapshots?.documents?.forEach { document ->
                    val ride = document.toObject(OwnRide::class.java)?.copy(sharedRoutesId = document.id)
                    if (ride != null) {
                        ridesList.add(ride)
                        Log.d(TAG, "fetchMyRides: Added ride ID: ${ride.sharedRoutesId}, Origin: ${ride.origin}")
                    } else {
                        Log.w(TAG, "fetchMyRides: Failed to parse document ${document.id}")
                    }
                }
                Log.d(TAG, "fetchMyRides: Total rides fetched: ${ridesList.size}")
                if (ridesList.isEmpty()) {
                    Log.d(TAG, "fetchMyRides: No rides found, showing noRidesText")
                    noRidesText.visibility = View.VISIBLE
                    recyclerView.visibility = View.GONE
                } else {
                    Log.d(TAG, "fetchMyRides: Rides found, showing RecyclerView")
                    noRidesText.visibility = View.GONE
                    recyclerView.visibility = View.VISIBLE
                    adapter.notifyDataSetChanged()
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        ridesListener?.remove()
        Log.d(TAG, "onDestroyView: Removed Firestore listener")
    }

    private inner class MyRidesAdapter(private val rides: List<OwnRide>) :
        RecyclerView.Adapter<MyRidesAdapter.RideViewHolder>() {

        inner class RideViewHolder(val binding: ItemOwnRidesBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RideViewHolder {
            val binding = ItemOwnRidesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return RideViewHolder(binding)
        }

        override fun onBindViewHolder(holder: RideViewHolder, position: Int) {
            val ride = rides[position]
            Log.d(TAG, "onBindViewHolder: Binding ride ID: ${ride.sharedRoutesId} at position: $position")

            with(holder.binding) {
                // Use cached riderName from the fragment
                riderName.text = this@MyRidesFragment.riderName ?: "Unknown"
                if (!this@MyRidesFragment.profileImageUrl.isNullOrEmpty()) {
                    Log.d(TAG, "onBindViewHolder: Loading profile image from URL: ${this@MyRidesFragment.profileImageUrl}")
                    Glide.with(profilePicture.context)
                        .load(this@MyRidesFragment.profileImageUrl)
                        .error(R.drawable.ic_anonymous)
                        .into(profilePicture)
                } else {
                    profilePicture.setImageResource(R.drawable.ic_anonymous)
                    Log.d(TAG, "onBindViewHolder: No profile image URL, using default for ride ID: ${ride.sharedRoutesId}")
                }

                dateCreated.text = ride.datetime?.toDate()?.let {
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(it)
                } ?: "Unknown"
                origin.text = "Origin: ${ride.origin ?: "Unknown"}"
                destination.text = "Destination: ${ride.destination ?: "Unknown"}"
                distance.text = "Distance: ${ride.distance?.let { String.format("%.1f km", it) } ?: "Unknown"}"
                duration.text = "Duration: ${ride.duration?.let { String.format("%.0f mins", it) } ?: "Unknown"}"
                rideNumbers.text = "${ride.joinedRiders?.size ?: 0} Riders"

                previewRideBtn.setOnClickListener {
                    Log.d(TAG, "onBindViewHolder: Preview button clicked for ride ID: ${ride.sharedRoutesId}")
                    val intent = Intent(context, PreviewRideActivity::class.java).apply {
                        putExtra("ride_datetime", ride.datetime?.toDate()?.time ?: 0L)
                        putExtra("ride_destination", ride.destination)
                        putExtra("ride_destination_lat", ride.destinationCoordinates?.get("latitude"))
                        putExtra("ride_destination_lng", ride.destinationCoordinates?.get("longitude"))
                        putExtra("ride_distance", ride.distance)
                        putExtra("ride_duration", ride.duration)
                        putExtra("ride_origin", ride.origin)
                        putExtra("ride_origin_lat", ride.originCoordinates?.get("latitude"))
                        putExtra("ride_origin_lng", ride.originCoordinates?.get("longitude"))
                        putExtra("ride_user_uid", ride.userUid)
                        putExtra("ride_id", ride.sharedRoutesId)

                    }
                    startActivity(intent)
                }

                cancelRideBtn.setOnClickListener {
                    val currentUserUid = auth.currentUser?.uid ?: return@setOnClickListener
                    Log.d(TAG, "onBindViewHolder: Cancel button clicked for ride ID: ${ride.sharedRoutesId}")
                    db.collection("sharedRoutes").document(ride.sharedRoutesId ?: return@setOnClickListener)
                        .update("status", "cancelled")
                        .addOnSuccessListener {
                            Toast.makeText(context, "Ride successfully cancelled", Toast.LENGTH_SHORT).show()
                            Log.d(TAG, "onBindViewHolder: Ride ID: ${ride.sharedRoutesId} successfully cancelled")
                        }
                        .addOnFailureListener { exception ->
                            Log.e(TAG, "onBindViewHolder: Failed to cancel ride ID: ${ride.sharedRoutesId}", exception)
                        }
                }
            }
        }

        override fun getItemCount(): Int = rides.size
    }
}