package com.aorv.blazerider

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aorv.blazerider.databinding.ActivityChatConversationBinding
import com.google.android.material.imageview.ShapeableImageView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.storage.FirebaseStorage
import com.bumptech.glide.Glide
import com.google.firebase.Timestamp
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class ChatConversationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatConversationBinding
    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var userNameTextView: TextView
    private lateinit var userImageView: ShapeableImageView
    private lateinit var callButton: ImageButton
    private lateinit var infoButton: ImageButton
    private lateinit var messageInput: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var messagesRecyclerView: RecyclerView
    private lateinit var typingIndicator: ImageView // Changed to ImageView for GIF
    private lateinit var messageAdapter: MessageAdapter
    private var messageListener: ListenerRegistration? = null
    private var typingListener: ListenerRegistration? = null
    private var chatId: String? = null
    private val PICK_FILE_REQUEST = 1001
    private val CAPTURE_IMAGE_REQUEST = 1002
    private val PICK_IMAGE_REQUEST = 1003
    private var photoUri: Uri? = null
    private val STORAGE_PERMISSION_REQUEST = 1004
    private val CAMERA_PERMISSION_REQUEST = 1005
    private val GALLERY_PERMISSION_REQUEST = 1006
    private var isTyping = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            binding = ActivityChatConversationBinding.inflate(layoutInflater)
            setContentView(binding.root)
        } catch (e: Exception) {
            setContentView(R.layout.activity_chat_conversation)
        }

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        userNameTextView = findViewById(R.id.user_name) ?: run {
            Log.e("ChatConversationActivity", "user_name TextView not found")
            Toast.makeText(this, "UI error: user_name not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        userImageView = findViewById(R.id.user_image) ?: run {
            Log.e("ChatConversationActivity", "user_image ImageView not found")
            Toast.makeText(this, "UI error: user_image not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        messagesRecyclerView = findViewById(R.id.messages_recycler_view)
        messageInput = findViewById(R.id.message_input)
        sendButton = findViewById(R.id.send_button)
        callButton = findViewById(R.id.call_button)
        infoButton = findViewById(R.id.info_button)
        typingIndicator = findViewById(R.id.typing_indicator) ?: run {
            Log.e("ChatConversationActivity", "typing_indicator ImageView not found")
            Toast.makeText(this, "UI error: typing_indicator not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val backButton = findViewById<ImageButton>(R.id.back_button)
        val fileButton = findViewById<ImageButton>(R.id.file_button)
        val cameraButton = findViewById<ImageButton>(R.id.camera_button)
        val galleryButton = findViewById<ImageButton>(R.id.gallery_button)

        // Load GIF into typing indicator
        Glide.with(this)
            .asGif()
            .load(R.drawable.typing_indicator)
            .into(typingIndicator)

        Log.d(
            "ChatConversationActivity",
            "UI elements initialized: userNameTextView=$userNameTextView, userImageView=$userImageView, typingIndicator=$typingIndicator"
        )

        // Handle phone's back button press
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish() // Close the activity when back button is pressed
            }
        })


        backButton.setOnClickListener { finish() }
        sendButton.setOnClickListener {
            sendMessage()
            if (isTyping) {
                isTyping = false
                updateTypingStatus(false)
            }
        }
        fileButton.setOnClickListener { openFilePicker() }
        cameraButton.setOnClickListener { openCamera() }
        galleryButton.setOnClickListener { openGallery() }

        messageInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val isCurrentlyTyping = !s.isNullOrEmpty()
                if (isCurrentlyTyping != isTyping && chatId != null) {
                    isTyping = isCurrentlyTyping
                    updateTypingStatus(isTyping)
                }
            }
        })

        chatId = intent.getStringExtra("chatId")
        val contact = intent.getSerializableExtra("CONTACT") as? Contact
        val currentUid = auth.currentUser?.uid ?: ""

        Log.d("ChatConversationActivity", "Received chatId: $chatId, contact: $contact")
        Log.d(
            "ChatConversationActivity",
            "Contact name: ${contact?.firstName} ${contact?.lastName}"
        )

        messageAdapter = MessageAdapter(currentUid, chatId ?: "", db)
        messagesRecyclerView.adapter = messageAdapter
        val layoutManager = LinearLayoutManager(this)
        layoutManager.stackFromEnd = true
        messagesRecyclerView.layoutManager = layoutManager

        if (contact != null) {
            val fullName =
                "${contact.firstName} ${contact.lastName}".trim().ifEmpty { "Unknown User" }
            Log.d("ChatConversationActivity", "Setting userNameTextView to: $fullName")
            userNameTextView.text = fullName
            Glide.with(this)
                .load(contact.profileImageUrl)
                .placeholder(R.drawable.ic_anonymous)
                .error(R.drawable.ic_anonymous)
                .into(userImageView)
            if (chatId != null) {
                listenForMessages(chatId!!)
                listenForTypingStatus(chatId!!, currentUid, fullName)
            } else {
                createNewP2PChat(contact.id)
            }
        } else if (chatId != null) {
            loadChatDetails(chatId!!)
            listenForMessages(chatId!!)
            listenForTypingStatus(chatId!!, currentUid, "Group Chat")
        } else {
            Log.e("ChatConversationActivity", "No contact or chatId provided")
            Toast.makeText(this, "Error: No contact or chat selected", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun updateTypingStatus(isTyping: Boolean) {
        val currentUid = auth.currentUser?.uid ?: return
        if (chatId == null) return

        db.collection("chats").document(chatId!!)
            .update("typing.$currentUid", isTyping)
            .addOnFailureListener { e ->
                Log.e("ChatConversation", "Failed to update typing status", e)
            }
    }

    private fun listenForTypingStatus(chatId: String, currentUid: String, displayName: String) {
        typingListener = db.collection("chats").document(chatId)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.e("ChatConversation", "Error listening for typing status", e)
                    return@addSnapshotListener
                }

                snapshot?.let {
                    val typingMap = it.get("typing") as? Map<String, Boolean> ?: emptyMap()
                    val isSomeoneTyping = typingMap.any { (userId, isTyping) ->
                        userId != currentUid && isTyping
                    }
                    typingIndicator.isVisible = isSomeoneTyping
                }
            }
    }

    private fun openFilePicker() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(
                this,
                permission
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(permission), STORAGE_PERMISSION_REQUEST)
            return
        }
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "*/*"
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        try {
            startActivityForResult(Intent.createChooser(intent, "Select a File"), PICK_FILE_REQUEST)
        } catch (e: Exception) {
            Toast.makeText(this, "No file manager found", Toast.LENGTH_SHORT).show()
            Log.e("ChatConversation", "Error opening file picker", e)
        }
    }

    private fun openCamera() {
        val permissions = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissions.add(Manifest.permission.CAMERA)
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissions.toTypedArray(),
                CAMERA_PERMISSION_REQUEST
            )
            return
        }
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val photoFile: File? = try {
            createImageFile()
        } catch (e: IOException) {
            null
        }
        photoFile?.let {
            photoUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", it)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
            startActivityForResult(intent, CAPTURE_IMAGE_REQUEST)
        } ?: run {
            Toast.makeText(this, "Failed to create photo file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openGallery() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(
                this,
                permission
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                Toast.makeText(
                    this,
                    "Storage permission is needed to access gallery",
                    Toast.LENGTH_LONG
                ).show()
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(permission),
                    GALLERY_PERMISSION_REQUEST
                )
            } else {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(permission),
                    GALLERY_PERMISSION_REQUEST
                )
            }
            return
        }
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        try {
            startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST)
        } catch (e: Exception) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
            Log.e("ChatConversation", "Error opening gallery", e)
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            PICK_FILE_REQUEST -> {
                if (resultCode == RESULT_OK) {
                    data?.data?.let { uri ->
                        Toast.makeText(this, "File selected: $uri", Toast.LENGTH_SHORT).show()
                        uploadFileToFirebase(uri)
                    }
                }
            }

            CAPTURE_IMAGE_REQUEST -> {
                if (resultCode == RESULT_OK) {
                    photoUri?.let { uri ->
                        val intent = Intent(this, PhotoPreviewActivity::class.java)
                        intent.putExtra("PHOTO_URI", uri.toString())
                        intent.putExtra("CHAT_ID", chatId)
                        startActivity(intent)
                    }
                }
            }

            PICK_IMAGE_REQUEST -> {
                if (resultCode == RESULT_OK) {
                    data?.data?.let { uri ->
                        val intent = Intent(this, PhotoPreviewActivity::class.java)
                        intent.putExtra("PHOTO_URI", uri.toString())
                        intent.putExtra("CHAT_ID", chatId)
                        startActivity(intent)
                    }
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            STORAGE_PERMISSION_REQUEST -> {
                Log.d(
                    "ChatConversation",
                    "Storage permission result: ${permissions.joinToString()}, ${grantResults.joinToString()}"
                )
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openFilePicker()
                } else {
                    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Manifest.permission.READ_MEDIA_IMAGES
                    } else {
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                    if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                        Toast.makeText(
                            this,
                            "Storage permission denied permanently. Please enable it in Settings.",
                            Toast.LENGTH_LONG
                        ).show()
                        val intent =
                            Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        intent.data = Uri.parse("package:$packageName")
                        startActivity(intent)
                    } else {
                        Toast.makeText(this, "Storage permission denied", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            CAMERA_PERMISSION_REQUEST -> {
                Log.d(
                    "ChatConversation",
                    "Camera permission result: ${permissions.joinToString()}, ${grantResults.joinToString()}"
                )
                val allGranted =
                    grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
                if (allGranted) {
                    openCamera()
                } else {
                    Toast.makeText(this, "Camera or storage permission denied", Toast.LENGTH_SHORT)
                        .show()
                }
            }

            GALLERY_PERMISSION_REQUEST -> {
                Log.d(
                    "ChatConversation",
                    "Gallery permission result: ${permissions.joinToString()}, ${grantResults.joinToString()}"
                )
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openGallery()
                } else {
                    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Manifest.permission.READ_MEDIA_IMAGES
                    } else {
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                    if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                        Toast.makeText(
                            this,
                            "Storage permission denied permanently. Please enable it in Settings.",
                            Toast.LENGTH_LONG
                        ).show()
                        val intent =
                            Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        intent.data = Uri.parse("package:$packageName")
                        startActivity(intent)
                    } else {
                        Toast.makeText(this, "Storage permission denied", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun uploadFileToFirebase(uri: Uri) {
        val storage = FirebaseStorage.getInstance()
        val fileRef = storage.reference.child("chat_files/${chatId}/${UUID.randomUUID()}")
        fileRef.putFile(uri)
            .addOnSuccessListener {
                fileRef.downloadUrl.addOnSuccessListener { downloadUri ->
                    sendFileMessage(downloadUri.toString(), "file")
                }
            }
            .addOnFailureListener { e ->
                Log.e("ChatConversation", "Failed to upload file", e)
                Toast.makeText(this, "Failed to upload file", Toast.LENGTH_SHORT).show()
            }
    }

    private fun sendFileMessage(fileUrl: String, type: String) {
        val currentUid = auth.currentUser?.uid ?: return
        val messageId = UUID.randomUUID().toString()
        val timestamp = Timestamp.now()

        val messageData = hashMapOf(
            "senderId" to currentUid,
            "content" to fileUrl,
            "timestamp" to timestamp,
            "type" to type,
            "readBy" to listOf(currentUid)
        )

        db.collection("chats").document(chatId!!).collection("messages")
            .document(messageId).set(messageData)
            .addOnSuccessListener {
                val lastMessage = hashMapOf(
                    "content" to if (type == "file") "File" else "Photo",
                    "senderId" to currentUid,
                    "timestamp" to timestamp
                )
                db.collection("chats").document(chatId!!)
                    .update("lastMessage", lastMessage)

                db.collection("chats").document(chatId!!).get()
                    .addOnSuccessListener { document ->
                        val members = document.get("members") as? Map<String, Map<String, Any>>
                            ?: return@addOnSuccessListener
                        members.keys.forEach { userId ->
                            db.collection("userChats").document(userId)
                                .collection("chats").document(chatId!!)
                                .get()
                                .addOnSuccessListener { userChatDoc ->
                                    val currentUnreadCount =
                                        userChatDoc.getLong("unreadCount") ?: 0L
                                    val updateData = hashMapOf(
                                        "lastMessage" to lastMessage,
                                        "unreadCount" to if (userId == currentUid) 0 else currentUnreadCount + 1
                                    )
                                    db.collection("userChats").document(userId)
                                        .collection("chats").document(chatId!!)
                                        .set(updateData)
                                }
                        }
                    }
            }
            .addOnFailureListener { e ->
                Log.e("ChatConversation", "Failed to send file message", e)
                Toast.makeText(this, "Failed to send file message", Toast.LENGTH_SHORT).show()
            }
    }

    private fun sendMessage() {
        val content = messageInput.text.toString().trim()
        if (content.isEmpty() || chatId == null) return

        val currentUid = auth.currentUser?.uid ?: return
        val messageId = UUID.randomUUID().toString()
        val timestamp = Timestamp.now()

        val messageData = hashMapOf(
            "senderId" to currentUid,
            "content" to content,
            "timestamp" to timestamp,
            "type" to "text",
            "readBy" to listOf(currentUid)
        )

        db.collection("chats").document(chatId!!).collection("messages")
            .document(messageId).set(messageData)
            .addOnSuccessListener {
                val lastMessage = hashMapOf(
                    "content" to content,
                    "senderId" to currentUid,
                    "timestamp" to timestamp
                )
                db.collection("chats").document(chatId!!)
                    .update("lastMessage", lastMessage)

                db.collection("chats").document(chatId!!).get()
                    .addOnSuccessListener { document ->
                        val members = document.get("members") as? Map<String, Map<String, Any>>
                            ?: return@addOnSuccessListener
                        members.keys.forEach { userId ->
                            db.collection("userChats").document(userId)
                                .collection("chats").document(chatId!!)
                                .get()
                                .addOnSuccessListener { userChatDoc ->
                                    val currentUnreadCount =
                                        userChatDoc.getLong("unreadCount") ?: 0L
                                    val updateData = hashMapOf(
                                        "lastMessage" to lastMessage,
                                        "unreadCount" to if (userId == currentUid) 0 else currentUnreadCount + 1
                                    )
                                    db.collection("userChats").document(userId)
                                        .collection("chats").document(chatId!!)
                                        .set(updateData)
                                }
                                .addOnFailureListener { e ->
                                    Log.e(
                                        "ChatConversation",
                                        "Failed to fetch unreadCount for user $userId",
                                        e
                                    )
                                }
                        }
                    }
                    .addOnFailureListener { e ->
                        Log.e("ChatConversation", "Failed to fetch chat members", e)
                    }

                messageInput.text.clear()
            }
            .addOnFailureListener { e ->
                Log.e("ChatConversation", "Failed to send message", e)
                Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadChatDetails(chatId: String) {
        db.collection("chats").document(chatId).get()
            .addOnSuccessListener { document ->
                if (!document.exists()) {
                    Log.w("ChatConversationActivity", "Chat document does not exist: $chatId")
                    return@addOnSuccessListener
                }

                val type = document.getString("type") ?: "group"
                val currentUid = auth.currentUser?.uid ?: return@addOnSuccessListener

                if (type == "p2p") {
                    val members = document.get("members") as? Map<String, Map<String, Any>>
                        ?: return@addOnSuccessListener
                    val otherUserId = members.keys.firstOrNull { it != currentUid }
                        ?: return@addOnSuccessListener

                    db.collection("users").document(otherUserId).get()
                        .addOnSuccessListener { userDoc ->
                            if (userDoc.exists()) {
                                val firstName = userDoc.getString("firstName") ?: ""
                                val lastName = userDoc.getString("lastName") ?: ""
                                val name = "$firstName $lastName".trim().ifEmpty { "Unknown User" }
                                val imageUrl = userDoc.getString("profileImageUrl")

                                userNameTextView.text = name
                                Glide.with(this)
                                    .load(imageUrl)
                                    .placeholder(R.drawable.ic_anonymous)
                                    .error(R.drawable.ic_anonymous)
                                    .into(userImageView)
                            } else {
                                Log.w("ChatConversationActivity", "User document not found for: $otherUserId")
                                userNameTextView.text = "Unknown User"
                                Glide.with(this)
                                    .load(R.drawable.ic_anonymous)
                                    .into(userImageView)
                            }
                        }
                        .addOnFailureListener { e ->
                            Log.e("ChatConversationActivity", "Failed to fetch user document", e)
                            userNameTextView.text = "Unknown User"
                            Glide.with(this)
                                .load(R.drawable.ic_anonymous)
                                .into(userImageView)
                        }
                } else if (type == "group") {
                    val name = document.getString("name") ?: "Group Chat"
                    val imageUrl = document.getString("groupImage") // Changed from "imageUrl" to "groupImage"

                    userNameTextView.text = name
                    Glide.with(this)
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_anonymous)
                        .error(R.drawable.ic_anonymous)
                        .into(userImageView)
                }
            }
            .addOnFailureListener { e ->
                Log.e("ChatConversationActivity", "Failed to load chat details for chatId: $chatId", e)
                userNameTextView.text = "Group Chat"
                Glide.with(this)
                    .load(R.drawable.ic_anonymous)
                    .into(userImageView)
            }
    }

    private fun createNewP2PChat(otherUserId: String) {
        val currentUid = auth.currentUser?.uid ?: return
        chatId = "${currentUid}_${otherUserId}"
        val timestamp = Timestamp.now()

        val chatData = hashMapOf(
            "type" to "p2p",
            "createdAt" to timestamp,
            "members" to hashMapOf(
                currentUid to hashMapOf(
                    "joinedAt" to timestamp,
                    "role" to "member"
                ),
                otherUserId to hashMapOf(
                    "joinedAt" to timestamp,
                    "role" to "member"
                )
            ),
            "typing" to hashMapOf(currentUid to false, otherUserId to false),
            "lastMessage" to null // Ensure this is consistent with your data model
        )

        db.collection("chats").document(chatId!!).set(chatData)
            .addOnSuccessListener {
                val userChatData = hashMapOf(
                    "lastMessage" to null, // Or use an empty map like hashMapOf("content" to "", "timestamp" to timestamp)
                    "unreadCount" to 0
                )
                db.collection("userChats").document(currentUid)
                    .collection("chats").document(chatId!!).set(userChatData)
                db.collection("userChats").document(otherUserId)
                    .collection("chats").document(chatId!!).set(userChatData)

                messageAdapter = MessageAdapter(currentUid, chatId!!, db)
                messagesRecyclerView.adapter = messageAdapter
                val layoutManager = LinearLayoutManager(this)
                layoutManager.stackFromEnd = true
                messagesRecyclerView.layoutManager = layoutManager
                listenForMessages(chatId!!)
                listenForTypingStatus(chatId!!, currentUid, userNameTextView.text.toString())
            }
            .addOnFailureListener { e ->
                Log.e("ChatConversation", "Failed to create chat", e)
            }
    }

    private fun listenForMessages(chatId: String) {
        messageListener = db.collection("chats").document(chatId)
            .collection("messages")
            .orderBy("timestamp")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.e("ChatConversation", "Error listening for messages", e)
                    return@addSnapshotListener
                }

                snapshot?.let {
                    val messages = it.documents.mapNotNull { doc ->
                        Message(
                            id = doc.id,
                            senderId = doc.getString("senderId") ?: "",
                            content = doc.getString("content") ?: "",
                            timestamp = doc.getTimestamp("timestamp") ?: Timestamp.now(),
                            type = doc.getString("type") ?: "text",
                            readBy = doc.get("readBy") as? List<String> ?: emptyList()
                        )
                    }

                    val messagesWithDividers = messages.mapIndexed { index, message ->
                        if (index == 0) {
                            message.copy(showDivider = true)
                        } else {
                            val prevMessage = messages[index - 1]
                            val timeDiff = message.timestamp.seconds - prevMessage.timestamp.seconds
                            val shouldShowDivider = when {
                                timeDiff >= 20 * 60 -> true
                                isDifferentDay(message.timestamp, prevMessage.timestamp) -> true
                                else -> false
                            }
                            message.copy(showDivider = shouldShowDivider)
                        }
                    }

                    messageAdapter.submitList(messagesWithDividers) {
                        messagesRecyclerView.scrollToPosition(messageAdapter.itemCount - 1)
                    }
                }
            }
    }

    private fun isDifferentDay(timestamp1: Timestamp, timestamp2: Timestamp): Boolean {
        val calendar1 = Calendar.getInstance().apply { time = timestamp1.toDate() }
        val calendar2 = Calendar.getInstance().apply { time = timestamp2.toDate() }
        return calendar1.get(Calendar.DAY_OF_YEAR) != calendar2.get(Calendar.DAY_OF_YEAR) ||
                calendar1.get(Calendar.YEAR) != calendar2.get(Calendar.YEAR)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isTyping && chatId != null) {
            updateTypingStatus(false)
        }
        messageListener?.remove()
        typingListener?.remove()
    }
}
